# Sherlocking collaborator recommendation — Qwen3 embeddings (v6)

This prototype recommends collaborator teams for one initiating professor from (i) publication-supported scientific coverage and (ii) initiator-centered structural-hole brokerage. **Qwen3-Embedding replaces TF-IDF completely** in the scoring pipeline. The included professor/paper examples are **synthetic**.

## Install and run

```bash
python -m pip install -r requirements.txt
python sherlocking.py recommend \
  --data examples/professors_v1.json \
  --query examples/proposal.json \
  --out output_qwen3
```

Defaults: `Qwen/Qwen3-Embedding-0.6B` (1024-dimensional), 3 additional collaborators maximum, `lambda_network=0.25`, 1 greedy + 30 randomized search runs, top-4 randomized restricted candidates, up to 12 sequential revision rounds. The first run may download the embedding model. **Do not interpret old v5 TF-IDF demo JSON as Qwen3 output.** Run this command to create real Qwen3 scores; this package does not ship precomputed Qwen3 results. Larger text embedding checkpoints are selectable with `--model Qwen/Qwen3-Embedding-4B` or `--model Qwen/Qwen3-Embedding-8B` when hardware supports them.

The embedding model is **not** a generative LLM. The separate `qwen_placeholder.py` is retained as an *optional, external* generative Qwen-based **requirement decomposition** placeholder; it does not run automatically and is independent of Qwen3-Embedding. You can supply requirements manually or use the literal sentence-splitting fallback.

## Scientific computation: requirements -> papers -> professors -> teams

For a project abstract and requirements `q_1,...,q_m` (weight `w_j`, nonnegative, sum `1`):

1. Use `SentenceTransformer("Qwen/Qwen3-Embedding-0.6B")`. Call **`encode_query`** for each requirement and the overall project abstract; call **`encode_document`** for every unique paper's title+abstract and each individual abstract sentence. Both sets of vectors are L2-normalized. Query/document role separation follows the Qwen3-Embedding retrieval interface.
2. For requirement `j` and paper `d`, compute cosine similarities:

   ```text
   D[j,d] = cos(Qwen3_query(q_j), Qwen3_document(title+abstract(d)))
   R[j,d] = max_{sentence s in abstract(d)} cos(Qwen3_query(q_j), Qwen3_document(s))
   z[j,d] = 0.5*D[j,d] + 0.5*R[j,d]
   P[d]   = cos(Qwen3_query(overall_project), Qwen3_document(title+abstract(d)))
   ```

3. **Qwen3 score calibration:** Old TF-IDF defaults `0.02/0.45` are removed. By default, get `ell` and `h` as **pooled 10th/90th percentiles of all `z[j,d]` for the current project and paper corpus**. Then:

   ```text
   s[j,d] = clip((z[j,d] - ell)/(h - ell), 0, 1)
   ```

   When all `z` values are effectively identical, assign `s=0.5` to all pairs (there is no rank information). Pass **both** `--threshold-low` and `--threshold-high` to override the percentile calibration with annotated, Qwen3-specific fixed cosine values. The JSON reports the actual cutoffs and method. The default scores are **query-relative retrieval strengths, not probabilities of relevance or expertise**; they are not directly comparable between projects/corpora. We recommend human-annotated calibration for production.

4. **Paper-level evidence labels**, not separate objective terms. Let `P75` and `P50` be the 75th/50th percentiles of `P[d]` across all unique papers; let `R75_j` be the 75th percentile of `R[j,d]` across papers. Default minimum calibrated score for a strong match: `t=0.65` (`--evidence-label-threshold` changes it).

   ```text
   if s[j,d] < t:                                       partial_or_weak_match
   elif P[d] >= P75:                                    similarity_candidate
   elif P[d] <= P50 and R[j,d] >= R75_j:                complementary_candidate_needs_review
   else:                                                partial_or_weak_match
   ```

   A similarity candidate has strong evidence *and resembles the overall project*. A complementarity candidate has strong **specific requirement evidence**, but its **overall project similarity** is relatively weak. The percentile choices are heuristics for discovery, not scientific validation. A paper may label differently across requirements.

5. Aggregate through **authorship**, not coauthorship:

   ```text
   a[p,j]  = max_{paper d authored by professor p} s[j,d]
   c[j,T]  = max_{professor p in team T} a[p,j]
   F_q(T)  = sum_j w_j*c[j,T]
   ```

   This is the **professor/team-level complementarity effect**: multiple professors can cover *different* requirements. There is **no direct professor-professor complementarity edge** or separate complementarity bonus. A shared paper is deduplicated, and its authorship does not establish which author was responsible for a specific result.

## Professor-only structural holes

Create `G_C`: professor nodes connected by **observed** undirected coauthorship, excluding all paper nodes and paper-to-requirement evidence edges. For a proposed team `T={u} ∪ S`, temporarily add initiator-to-candidate edges to get `G_T` (do **not** mutate the observed graph).

For nonadjacent neighbors `v,w` of initiator `u`, let `r_vw(G)` be the number of common neighbors (two-hop intermediaries). With the harmonic case from Kleinberg et al. and direct-link coefficient `alpha_0=1`:

```text
H_u(G) = sum_{unordered {v,w} subset N_G(u), (v,w) not in E(G)} 2/r_vw(G)
Z      = 2 * ( degree_GC(u) * K + K*(K-1)/2 )
B_u(T) = (H_u(G_T) - H_u(G_C)) / Z       [0 when Z=0]
J_q(T) = F_q(T) + lambda_network * B_u(T)
```

**Attribution:** The two-hop intermediary model and `beta(r)=2*alpha_0/r` are from *Strategic Network Formation with Structural Holes* by Kleinberg, Suri, Tardos and Wexler: https://www.cs.cornell.edu/home/kleinber/ec08-struct-holes.pdf. **Taking the initiator's hypothetical gain, dividing it by `Z`, and combining it with scientific coverage are our design choices, not formulas proposed in that paper.** The paper's full utility also has direct-neighbor benefits and link-maintenance costs, excluded here.

## Sequential search

The objective and the scientific evidence are fixed during search. First run deterministic greedy construction; then run multiple randomized greedy constructions. Both repeatedly recompute `Delta J(p|S)=J(S+{p})-J(S)` after each addition. Randomized construction samples among the top `--top-r` positive marginal candidates; early restarts also force different first candidates. Then each run attempts sequentially evaluated add/swap/remove edits, immediately accepting improving edits and rescoring the updated team. A round with no accepted edit stops the run. Both search modes refine **teams**, not paper similarity/complementarity edges.

Distinct visited teams are pooled. By default, the recommended first team maximizes `J` among teams within `--science-tolerance 0.03` of the strongest discovered scientific score. Optional `--exact-check-max-candidates 20` exhaustively checks small candidate pools.

## Outputs and verification

`recommendations.json`: team scores and evidence; `recommended_teams.csv`, `recommended_edges.csv`: readable recommendations; `paper_evidence.json/.csv`: Qwen3 cosine components, best sentence and tentative label; `professor_scores.json`: paper-to-professor aggregation; `query_evidence_graph.json`: per-project paper-to-requirement candidate edges; `graph.json`: authorship and observed coauthorship; `trace.json`, `rounds.csv`: stepwise greedy/randomized decisions; `requirements.json`: normalized requirements.

Run model-free integration and mathematical invariant tests with:

```bash
pip install -r requirements-dev.txt
python -m pytest -q
```

These tests use deterministic stand-in embeddings and a mocked Qwen3 `SentenceTransformer` to check input role separation and numerical plumbing; **passing them is not evidence that real model weights were executed, that embedding relevance is calibrated, or that scientific contribution was verified**. Real Qwen3 predictions require model weights, which are not bundled.

For generating/merging requirements via the separate *generative* Qwen placeholder:

```bash
python sherlocking.py decompose --query examples/proposal.json --mode qwen-placeholder --out qwen_request.json
python sherlocking.py merge-qwen --query examples/proposal.json --response real_qwen_response.json --out query_from_qwen.json
```

Use `evolve --data ... --update ... --out ...` to apply **observed**, verified new publications/coauthorship; proposed team links never become observed by default.
