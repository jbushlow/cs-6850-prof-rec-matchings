"""Numerical invariants and offline integration tests. Qwen3 calls mocked: no weights downloaded."""
from __future__ import annotations

import json
import re
import sys
import types
from pathlib import Path

import networkx as nx
import numpy as np
import pytest

from qwen_placeholder import build_qwen_request, merge_qwen_response
from sherlocking import (Objective, TextEncoder, build_heterogeneous_graph,
                         evolve, export_results, heuristic_requirements,
                         load_json, make_collaboration_graph, recommend,
                         resolve_requirements, score_papers, sequential_search, evidence_type)

class StubQwen3Embeddings:
    """Deterministic test doubles for Qwen3 vectors (not used for real predictions)."""
    backend = "qwen3"
    model = "offline-test-stub"

    def _encode(self, texts):
        # Fixed small bag-of-words vectors, for offline plumbing tests only.
        vocab = ("ultrasound", "image", "reconstruction", "cat", "cats",
                 "cardiac", "vision", "clinical", "testing", "science", "fur")
        vectors = []
        for text in texts:
            words = re.findall(r"[a-z]+", text.lower())
            vec = np.array([words.count(word) for word in vocab], dtype=float)
            norm = np.linalg.norm(vec)
            vectors.append(vec / norm if norm else vec)
        return np.stack(vectors)

    def encode_queries(self, texts):
        return self._encode(texts)

    def encode_documents(self, texts):
        return self._encode(texts)


ROOT = Path(__file__).resolve().parents[1]
EX = ROOT / "examples"


def obj(graph, rows, weights=(1.,), max_additional=3, lambda_network=.25):
    return Objective("u", graph, {p: np.asarray(v, dtype=float) for p, v in rows.items()},
                     weights, max_additional=max_additional, lambda_network=lambda_network)


def test_heterogeneous_graph_deduplicates_shared_paper_and_professor_projection():
    data = load_json(EX/"professors_v2.json")
    h = build_heterogeneous_graph(data)
    g = make_collaboration_graph(data)
    assert all(h.nodes[f"prof:{p}"]["node_type"] == "professor" for p in g.nodes)
    assert h.nodes["paper:joint_cat_ultrasound_2026"]["node_type"] == "paper"
    shared = "paper:joint_cat_ultrasound_2026"
    assert h.has_edge("prof:cv_lee", shared)
    assert h.has_edge("prof:vet_morgan", shared)
    assert len([n for n in h.nodes if n == shared]) == 1
    assert all(not node.startswith("paper:") for node in g.nodes)
    assert all(h.edges[e]["edge_type"] == "authorship" for e in [("prof:cv_lee", shared),
                                                                    ("prof:vet_morgan", shared)])


def test_max_science_includes_initiator_but_not_unselected_coauthors():
    g = nx.Graph()
    g.add_edges_from([("u", "neighbor")])
    g.add_node("candidate")
    o = obj(g, {"u": [.8, .2], "neighbor": [1., 1.], "candidate": [.3, .9]},
            weights=(.5, .5), max_additional=2)
    assert o.science(frozenset()) == pytest.approx(.5)  # NOT 1 from neighbor
    assert o.science(frozenset({"candidate"})) == pytest.approx(.85)
    assert o.science(frozenset({"candidate", "neighbor"})) == pytest.approx(1.)
    assert o.science(frozenset({"neighbor", "candidate"})) == pytest.approx(1.)
    assert o.network(frozenset({"neighbor"})) == pytest.approx(0)


def test_brokerage_open_wedge_closed_triangle_and_competing_intermediary():
    g = nx.Graph()
    g.add_edges_from([("u", "a"), ("u", "b")])
    a = {p: [0.] for p in g.nodes}
    o = obj(g, a)
    assert o.h(frozenset()) == pytest.approx(2)  # r_ab=1
    g.add_edge("a", "b")
    o = obj(g, a)
    assert o.h(frozenset()) == pytest.approx(0)
    g.remove_edge("a", "b")
    g.add_edges_from([("a", "z"), ("z", "b")])
    a["z"] = [0.]
    o = obj(g, a)
    assert o.h(frozenset()) == pytest.approx(1)  # r_ab=2


def test_brokerage_only_rewards_open_nonredundant_wedges_not_direct_edges():
    g = nx.empty_graph(["u", "v", "w"])
    o = obj(g, {p: [0.] for p in g.nodes}, max_additional=2)
    assert o.Z == pytest.approx(2)
    assert o.h(frozenset()) == 0
    assert o.h(frozenset({"v"})) == 0
    assert o.network(frozenset({"v"})) == 0
    assert o.h(frozenset({"w", "v"})) == pytest.approx(2)
    assert o.network(frozenset({"v", "w"})) == pytest.approx(1)
    assert not g.has_edge("u", "v")  # does not mutate observed graph


def test_one_existing_neighbor_and_one_new_broker():
    g = nx.Graph()
    g.add_edge("u", "a")
    g.add_node("b")
    o = obj(g, {p: [0.] for p in g}, max_additional=2)
    assert o.Z == pytest.approx(2*(1*2+1))
    assert o.network(frozenset({"b"})) == pytest.approx(2/6)
    assert o.network(frozenset({"a"})) == pytest.approx(0)


def test_paper_level_score_and_published_passage_alignment():
    data = {"professors": [
        {"id": "u", "name": "U", "papers": [{"id": "x", "title": "Unrelated",
                                                   "abstract": "Cars are moving. Cats have fur."}]},
        {"id": "v", "name": "V", "papers": [{"id": "d", "title": "Ultrasound image reconstruction",
                                                   "abstract": "We develop ultrasound image reconstruction. We test cats."}]}],
            "coauthorship_edges": []}
    reqs = resolve_requirements({"initiator_id": "u", "requirements": [
        {"description": "ultrasound image reconstruction", "weight": 1}]}, {"u", "v"})
    scores, selected, rows, calibration = score_papers(data, reqs, StubQwen3Embeddings(), low=0, high=1)
    assert float(scores["v"][0]) > float(scores["u"][0])
    d = next(row for row in rows if row["paper_id"] == "d")
    assert "ultrasound image reconstruction" in d["supporting_abstract_sentence"].lower()
    assert d["raw_combined_cosine"] == pytest.approx(.5*(d["document_cosine"]+d["sentence_cosine"]), abs=1e-6)
    assert selected["v"][0]["paper_id"] == "d"
    assert calibration["method"] == "fixed_user_supplied"


def test_shared_paper_does_not_double_count_team_coverage():
    g = nx.empty_graph(["u", "v", "w"])
    o = obj(g, {"u": [.1], "v": [.8], "w": [.8]}, max_additional=2)
    assert o.science(frozenset({"v"})) == pytest.approx(.8)
    assert o.science(frozenset({"v", "w"})) == pytest.approx(.8)


def test_value_same_for_same_team_independent_of_order():
    g = nx.empty_graph(["u", "a", "b", "c"])
    o = obj(g, {"u": [.1, .2], "a": [.9, .1], "b": [.1, .9], "c": [.4, .3]},
            weights=(.6, .4))
    assert o.value(frozenset({"a", "b"})) == o.value(frozenset({"b", "a"}))
    assert o.marginal("b", frozenset()) != pytest.approx(o.marginal("b", frozenset({"a"})))


def test_randomized_sequential_forced_first_and_trace():
    g = nx.empty_graph(["u", "a", "b", "c"])
    o = obj(g, {"u": [.1, .1], "a": [.9, .1], "b": [.2, .8], "c": [.1, .9]},
            weights=(.5, .5), max_additional=2)
    run = sequential_search(["a", "b", "c"], o, seed=8, forced_first="b", max_rounds=3)
    assert run["events"][0]["action"] == "forced_first"
    assert run["events"][0]["additional_after"] == ["b"]
    for evt in run["events"]:
        assert evt["combined_after"] == pytest.approx(o.value(frozenset(evt["additional_after"])), abs=1e-6)
    assert len(run["final_additional"]) <= 2


def test_qwen_placeholder_includes_only_input_abstract_and_strict_merge():
    query = {"initiator_id": "private_u", "abstract": "Study cardiac ultrasound and clinical testing.",
             "professors": [{"secret": "DO NOT SEND"}], "title": "Title"}
    request = build_qwen_request(query)
    assert request["status"] == "PLACEHOLDER_NO_MODEL_CALLED"
    assert request["input"] == {"abstract": query["abstract"]}
    assert "DO NOT SEND" not in json.dumps(request)
    merged = merge_qwen_response(query, {"requirements": [
        {"description": "Cardiac ultrasound", "weight": 2.0},
        {"description": "Clinical testing", "weight": 1.0}]})
    assert merged["initiator_id"] == "private_u"
    assert merged["requirements"][0]["weight"] == 2.0
    assert "requirements" not in query
    with pytest.raises(ValueError):
        merge_qwen_response(query, {"requirements": [{"description": "x", "weight": 1}], "score": 1})
    with pytest.raises(ValueError):
        merge_qwen_response(query, {"requirements": [{"description": "x", "weight": float("nan")}]})


def test_heuristic_decomposes_only_from_abstract():
    parts = heuristic_requirements("Study ultrasound imaging. Validate on clinical cases; evaluate sensitivity.")
    assert len(parts) == 3
    assert "ultrasound" in parts[0]["description"]


def test_complete_recommend_outputs_multiple_unique_teams_and_trace(tmp_path):
    data = load_json(EX/"professors_v1.json")
    query = load_json(EX/"proposal.json")
    art = recommend(data, query, encoder=StubQwen3Embeddings(), restarts=15, max_rounds=4,
                    n_teams=5, seed=42)
    result = art["result"]
    teams = result["recommended_teams"]
    assert 2 <= len(teams) <= 5
    assert len({tuple(t["professor_ids"]) for t in teams}) == len(teams)
    assert all(t["professor_ids"][0] == query["initiator_id"] and len(t["professor_ids"]) <= 4
               for t in teams)
    assert result["selected_default_team"] == teams[0]
    assert all(len(t["hypothetical_collaboration_links"]) == t["additional_count"] for t in teams)
    assert all(t["scientific_score"] <= 1 and 0 <= t["brokerage_score"] <= 1 for t in teams)
    assert all(len(t["per_requirement"]) == len(query["requirements"]) for t in teams)
    assert len(art["graph"]["nodes"]) > len(data["professors"])
    assert any(e["edge_type"] == "query_scientific_evidence" for e in art["query_graph"]["edges"])
    assert not any(e["edge_type"] == "query_scientific_evidence" for e in art["graph"]["edges"])
    assert all("visited" not in run for run in art["trace"]["randomized_runs"])
    export_results(tmp_path, art)
    assert (tmp_path/"recommended_teams.csv").exists()
    assert (tmp_path/"paper_evidence.csv").exists()
    assert (tmp_path/"trace.json").exists()
    assert (tmp_path/"query_evidence_graph.json").exists()
    assert json.loads((tmp_path/"recommendations.json").read_text()) == result


def test_exact_crosscheck_and_outer_observed_update():
    data = load_json(EX/"professors_v1.json")
    updated = evolve(data, load_json(EX/"observed_update.json"))
    assert updated["version"] == data["version"]+1
    assert len(make_collaboration_graph(updated).edges) >= len(make_collaboration_graph(data).edges)
    assert data != updated
    small = {"professors": [
        {"id": "u", "name": "U", "papers": [{"id": "p0", "abstract": "ultrasound image"}]},
        {"id": "a", "name": "A", "papers": [{"id": "p1", "abstract": "ultrasound science"}]},
        {"id": "b", "name": "B", "papers": [{"id": "p2", "abstract": "image science"}]}],
        "coauthorship_edges": []}
    q = {"initiator_id": "u", "requirements": [{"description": "ultrasound science", "weight": 1}]}
    art = recommend(small, q, encoder=StubQwen3Embeddings(), restarts=2, n_teams=3, exact_check_max_candidates=5)
    assert art["result"]["exact_check"]["enumerated_team_count"] == 4
    assert art["result"]["exact_check"]["best_objective"] >= art["result"]["selected_default_team"]["combined_score"]-1e-6


def test_conflicting_shared_paper_metadata_rejected():
    data = {"professors": [
        {"id": "u", "name": "U", "papers": [{"id": "shared", "abstract": "a"}]},
        {"id": "v", "name": "V", "papers": [{"id": "shared", "abstract": "b"}]}]}
    with pytest.raises(ValueError, match="Conflicting"):
        recommend(data, {"initiator_id": "u", "abstract": "Query."}, encoder=StubQwen3Embeddings())


def test_qwen3_encoder_query_and_document_roles(monkeypatch):
    calls = []

    class FakeSentenceTransformer:
        def __init__(self, checkpoint):
            assert checkpoint == "Qwen/Qwen3-Embedding-0.6B"
            calls.append("model_load")

        def encode_query(self, texts, **kwargs):
            calls.append(("query", list(texts)))
            assert kwargs["normalize_embeddings"] is True
            return np.tile([1.0, 0.0], (len(texts), 1))

        def encode_document(self, texts, **kwargs):
            calls.append(("document", list(texts)))
            return np.tile([0.0, 1.0], (len(texts), 1))

    monkeypatch.setitem(sys.modules, "sentence_transformers",
                        types.SimpleNamespace(SentenceTransformer=FakeSentenceTransformer))
    encoder = TextEncoder()
    q = encoder.encode_queries(["Find cardiology expertise"])
    d = encoder.encode_documents(["Cardiology paper"])
    assert q.shape == d.shape == (1, 2)
    assert calls == ["model_load", ("query", ["Find cardiology expertise"]),
                     ("document", ["Cardiology paper"])]
    with pytest.raises(ValueError, match="Only the Qwen3"):
        TextEncoder(backend="tfidf")


def test_complementarity_is_strong_requirement_weak_project_not_professor_edge():
    cutoffs = dict(strong_project_cutoff=.8, weak_project_cutoff=.5,
                   strong_sentence_cutoff=.7, score_threshold=.65)
    assert evidence_type(.85, .77, .9, **cutoffs) == "similarity_candidate"
    assert evidence_type(.4, .77, .9, **cutoffs) == "complementary_candidate_needs_review"
    assert evidence_type(.4, .55, .9, **cutoffs) == "partial_or_weak_match"
    assert evidence_type(.85, .9, .4, **cutoffs) == "partial_or_weak_match"


def test_qwen3_automatic_score_calibration_is_query_relative_and_bounded():
    data = load_json(EX/"professors_v1.json")
    query = load_json(EX/"proposal.json")
    art = recommend(data, query, encoder=StubQwen3Embeddings(), restarts=0, max_rounds=1)
    cal = art["result"]["raw_similarity_calibration"]
    assert cal["method"].startswith("within_query_p10_p90")
    assert cal["low"] < cal["high"]
    assert cal["percentiles"] == [10, 90]
    assert all(0 <= row["score"] <= 1 for row in art["paper_evidence"])
    with pytest.raises(ValueError, match="both"):
        recommend(data, query, encoder=StubQwen3Embeddings(), threshold_low=.2)
