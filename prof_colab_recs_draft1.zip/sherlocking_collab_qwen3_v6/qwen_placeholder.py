"""Qwen-only-one-abstract interface contract. NO inference or paper processing.

A future implementation may use any chosen Qwen text model to convert ONLY
`abstract` into requirements; it must not see publication data, professor
records, the graph, retrieved papers, candidate lists, or scores.

Input JSON:
 {"initiator_id": "prof_a", "title": "...", "abstract": "..."}

Required Qwen response (strict JSON; not markdown):
 {"requirements": [{"description": "one independently assessable research need",
                    "weight": 1.0}, ...]}

No novel details. No fabrication. Each requirement faithful to the abstract.
Weights finite and >= 0; at least one > 0. They are normalized by scoring.
Your integration should validate the output and merge ONLY 'requirements'
into the original query. Do NOT pass full faculty/paper data to Qwen.
"""
from __future__ import annotations

from copy import deepcopy

INSTRUCTIONS = """You are a REQUIREMENTS DECOMPOSER, not a recommender.
You will receive ONE input: a research project abstract.
Your ONLY task is to split it into specific, independently assessable research
requirements that can each be checked against evidence in publication abstracts.

Rules:
- Use only facts explicitly in the supplied abstract. Do not infer unstated
  researchers, methods, datasets, equipment, results or domains.
- Distinguish methods, scientific/domain expertise, data/equipment needs, and
  experimental/validation methods when they are actually mentioned.
- Avoid broad field labels when a narrower explicit task/method is stated.
- Keep distinct needs separate, but do not fragment trivial synonyms.
- Preserve technical terminology verbatim wherever appropriate.
- Do NOT rank, score, or recommend researchers or papers.
- Do NOT ask for or process publications, professor profiles, coauthors or graph.
- Return ONLY valid JSON with the exact top-level key 'requirements'.
- Each requirement object has exactly 'description' (nonempty string) and
  'weight' (nonnegative finite number). Use equal weights of 1.0 if the
  abstract provides no credible priority information; a human may edit them.
- If there is insufficient information, retain the text as one requirement
  rather than inventing specificity.

Output schema:
{"requirements":[{"description":"...","weight":1.0}]}
"""


def build_qwen_request(query):
    abstract = query.get("abstract")
    if not isinstance(abstract, str) or not abstract.strip():
        raise ValueError("A project abstract is required for Qwen decomposition")
    # Deliberately exclude initiator ID, title and all other query metadata.
    return {"status": "PLACEHOLDER_NO_MODEL_CALLED", "system_instructions": INSTRUCTIONS,
            "input": {"abstract": abstract},
            "expected_output_schema": {"requirements": [{"description": "nonempty string", "weight": 1.0}]},
            "integration_steps": [
                "Send ONLY system_instructions and input.abstract to your Qwen model.",
                "Parse the response as JSON, rejecting any prose, additional keys, or invented claims.",
                "Call merge_qwen_response(original_query, parsed_response).",
                "Save the returned query JSON and pass it to sherlocking.py recommend --query.",
                "NEVER send paper abstracts, professor profiles, edges, retrieval results or scores to Qwen."
            ]}


def merge_qwen_response(query, response):
    """Validate Qwen-generated requirement JSON; preserve original metadata."""
    import math
    if not isinstance(response, dict) or set(response) != {"requirements"}:
        raise ValueError("Qwen response must have exactly one key: requirements")
    requirements = response["requirements"]
    if not isinstance(requirements, list) or not requirements:
        raise ValueError("requirements must be a nonempty list")
    normalized = []
    for r in requirements:
        if not isinstance(r, dict) or set(r) != {"description", "weight"}:
            raise ValueError("Each requirement must have exactly description and weight")
        if not isinstance(r["description"], str) or not r["description"].strip():
            raise ValueError("Requirement description must be nonempty")
        if isinstance(r["weight"], bool) or not isinstance(r["weight"], (int, float)):
            raise ValueError("Requirement weight must be numeric")
        weight = float(r["weight"])
        if not math.isfinite(weight) or weight < 0:
            raise ValueError("Requirement weights must be finite and >=0")
        normalized.append({"description": r["description"].strip(), "weight": weight})
    if not any(r["weight"] > 0 for r in normalized):
        raise ValueError("At least one requirement weight must be positive")
    new_query = deepcopy(query)
    new_query["requirements"] = normalized
    return new_query


def write_qwen_request(query, filepath):
    from sherlocking import save_json
    save_json(filepath, build_qwen_request(query))
